ColorFill game and solver - yet another Flood-It / Globs clone

Version   0.1.8 (2015-03-15)
Homepage  https://github.com/smack42/ColorFill/wiki



usage

Java SE Runtime Environment (JRE version 6 or newer) is required to run
this program. You can download Java here:
http://www.oracle.com/technetwork/java/javase/downloads/index.html

To run the program just doubleclick "colorfill.jar".




license

ColorFill game and solver
Copyright (C) 2015 Michael Henke <smack42@gmail.com>

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.




some links

Online game
    http://floodit.appspot.com/
    http://www.jacksmack.com/games/550/globs.html

Android app
    https://play.google.com/store/apps/details?id=com.labpixies.flood
    https://play.google.com/store/apps/details?id=com.wetpalm.colorflood
    http://www.elevatefun.com/games/globs/

Programming
    http://cplus.about.com/od/programmingchallenges/a/challenge19.htm
    https://stackoverflow.com/questions/1430962/how-to-optimally-solve-the-flood-fill-puzzle
    http://markgritter.livejournal.com/tag/floodit
    http://kunigami.wordpress.com/2012/09/16/flood-it-an-exact-approach/
